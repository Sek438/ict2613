<?php
// database connection constants
define("DATA_SOURCE_NAME", "mysql:host=localhost;dbname=medical");
define("DATABASE_USERNAME", "root");
define("DATABASE_PASSWORD", "");
?>

