<?php

include 'db_config.php';

// connect to database
try {
  $db = new PDO(DATA_SOURCE_NAME, DATABASE_USERNAME, DATABASE_PASSWORD);
  $message = "Database connection successfull";
} catch (PDOException $e) {
  $message = "Error: " . $e->getMessage();
  exit();
}

//get all data from table
function query_all() {
    global $db;
    $query = "SELECT * FROM doctors
            ORDER BY practicenumber";
    $statement = $db->prepare($query);
    $statement->execute();
    $results = $statement->fetchAll();
    $statement->closeCursor();
    return $results;
}

//get selected data from table based on user input
function query_selected($selected_fee) {
    global $db;
    $query = "SELECT * FROM doctors
            WHERE fee < :selected_fee
            ORDER BY practicenumber";
    $statement = $db->prepare($query);
    $statement->bindValue(':selected_fee', $selected_fee);
    $statement->execute();
    $selected_results = $statement->fetchAll();
    $statement->closeCursor();
    return $selected_results;
}
// declare variables
$query_results = "";
$query_option = filter_input(INPUT_POST, 'query_option');
$consult_fee = filter_input(INPUT_POST, 'consult_fee', FILTER_VALIDATE_FLOAT);
if ($_POST != NULL) {
    if ($query_option == 'selected') {
        $query_results = query_selected($consult_fee);
    } else {
        $query_results = query_all();
    }
}

?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="main.css">
        <title>Task 4</title>
    </head>
    <body>
        <header>
            <?php include 'menu.inc'; ?>
        </header>
        
        <main>
            <!-- output -->
            <h2>Output</h2>
            <div class="output">
                <div class="left">
                    <!-- display database connection result here  -->
                    <div class="info_message">
                        <?php echo $message;  ?>
                    </div><br>

                    <!-- form to get user input -->
                    <form action="task4.php" method="post">
                        <label for="query_option">Select data to view: </label>
                        <select name="query_option">
                            <option value="all">All data</option>
                            <option value="selected">Less than maximum fee</option>
                        </select>
                      <br>
                      <label for="consult_fee">Enter maximum fee: </label>
                      <input type="number" name="consult_fee">
                      <br>
                      <label>&nbsp;</label>
                      <input type="submit" value="Submit" />
                    </form>
                </div>
                
                <div class="left">
                    <!-- table to display query results -->
                    <table>
                        <tr>
                            <th>Practice Number</th>
                            <th>Name</th>
                            <th>Speciality</th>
                            <th>Fee</th>
                        </tr>

                        <!-- populate table with with query results foreach loop -->
                        <?php if ($query_results != "") : ?>
                        <?php foreach ($query_results as $result ) : ?>
                        <tr>
                            <td>
                                <?php echo $result['practicenumber']; ?>
                            </td>
                            <td>
                                <?php echo $result['name']; ?>
                            </td>
                            <td>
                                <?php echo $result['specialty']; ?>
                            </td>
                            <td class="numbers_col">
                                <?php echo $result['fee']; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </table>
                </div>
                <div class="clear"></div>
            </div>
          
            <!-- iframe containg PHP source code -->
            <iframe src="task4.txt"> 
                Your browser does not support iframes. 
            </iframe>
        </main>
    </body>
</html>