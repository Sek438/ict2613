<?php
    // declare varibales and set initail values
    $bmi = '';
    $bmi_f = NULL;
    $error_message = '';
    
    // get data from form
    $system = filter_input(INPUT_POST, 'system');
    $weight = filter_input(INPUT_POST, 'weight', FILTER_VALIDATE_FLOAT);
    $height = filter_input(INPUT_POST, 'height', FILTER_VALIDATE_FLOAT);
        
    // convert imperial to metric if selected
    if ($system == 'imperial') {
        $weight *= 0.453;
        $height *= 0.025;
    }
       
    // set error messages
    if (isset($weight) && isset($height)) {
        if ($weight == FALSE) {
            $error_message = 'Please enter a valid number for your weight';
        } else if ($height == FALSE) {
            $error_message = 'Please enter a valid number for your height';        
        } else if ($weight <= 0) {
            $error_message = 'Weight should be more than zero';
        } else if ($height <= 0) {
            $error_message = 'Height should be more than zero';
        } else {
            $error_message = '';
        }
    }    
    
    //calculate BMI
    if ($weight && $height) {
        $bmi = $weight / ($height * $height);
        $bmi_f = number_format($bmi, 1);
    }
       
    // set value of weight indicator
    if ($bmi_f < 18.5) {
        $weight_indicator = 'Underweight';
    } else if ($bmi_f >= 18.5 || $bmi <= 24.9 ) {
        $weight_indicator = 'Healthy weight';
    } else if ($bmi_f >= 25 || $bmi <= 29.9) {
        $weight_indicator = 'Overweight';
    } else if ($bmi_f > 30) {
        $weight_indicator = 'Obese';
    } 
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="main.css">
        <title>Task 3</title>
    </head>
    <body>
        <header>
            <?php include 'menu.inc'; ?>
        </header>
        
        <main>
            <!-- output -->
            <h2>Task 3</h2>
            <div class="output">
                <h3>BMI Calculator</h3>
                <?php if ($error_message != '') { ?>
                    <p class="error_message"><?php echo htmlspecialchars($error_message) ?></p>
                <?php }?>                
                <form action="task3.php" method="post">
                    <label>Measurement system: </label>
                    <input type="radio" name="system" value="imperial"><span>Imperial</span>
                    <input type="radio" name="system" value="metric" checked><span>Metric</span><br>
                    <br><br>
                    <label for="weight">Enter weight: </label>
                    <input type="text" name="weight"><span>&nbsp;(Pounds or Kilograms)</span><br>                    
                    <label>Enter height: </label>
                    <input type="text" name="height"><span>&nbsp;(Inches or Meters)</span><br>
                    <label>&nbsp;</label>
                    <input type="submit" value="Calculate BMI">
                </form>
                <div>
                    <?php if ($bmi > 0) { ?>
                        <p>Your Body Mass Index is: <span class="result"><?php echo $bmi_f ?></span></p>
                        <p>This means that you are: <span class='result'><?php echo $weight_indicator ?></span></p>
                    <?php } ?>
                </div>
            </div>
          
            <!-- iframe containing PHP source code -->
            <iframe src="task3.txt"> 
                Your browser does not support iframes. 
            </iframe>
        </main>
    </body>
</html>