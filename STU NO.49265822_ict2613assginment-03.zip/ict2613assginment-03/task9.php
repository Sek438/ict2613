<?php
    
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="main.css">
        <title>Task 9</title>
    </head>
    <body>
        <header>
            <?php include 'menu.inc'; ?>
        </header>
        
        <main>
            <!-- output -->
            <h2>Output</h2>
            <div class="output">
                
<?php

$date1 = new DateTime('29-03-1980');
echo $date1->format('d/m/Y')."<br>";

$date2 = new DateTime('31-12-1996'); //current date

$dateInterval = $date1->diff($date2);

echo $dateInterval->format('%y years');

if($date1->format('d-m') > $date2->format('d-m')) {
    echo "<p>You have already celebrated your birthday this year</p>";
}
elseif($date1->format('d-m') == $date2->format('d-m')) {
    echo "<p>It’s your birthday today</p>";
}
else {
    echo "<p>Your birthday is yet to come this year</p>";
}
?>


            </div>
         
            <!-- iframe containg PHP source code -->
            <iframe src="task9.txt" height="400" width="1200"> 
                Your browser does not support iframes. 
            </iframe>
        </main>
    </body>
</html>