<?php
    
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="main.css">
        <title>Task 7</title>
    </head>
    <body>
        <header>
            <?php include 'menu.inc'; ?>
        </header>
        
        <main>
            <!-- output -->
            <h2>Output</h2>
            <div class="output">

                <?php
 echo "Task 7a"; 
 echo "<br>"; 
          
        $array = Array(1,1,2,4,7,11,16,22,29,37,46,56,67,79,92,106,121,137,154,172);
        for ($i = 0; $i < count($array); $i++){
            if ($array[$i] % 2 === 0){ 
                echo " [".$array[$i]."] ";
            } else {
                 echo $array[$i]. ' ';
            }
        }



  echo "</br></br>";  
          
       echo  "Task 7b ";  
   echo "</br></br>";     
       $counter = 0;
        while ($counter < count($array)){
            if ($array[$counter] % 2 === 0){ 
                 echo $array[$counter]. ' ';
            } else {
                 echo" {".$array[$counter]."} ";
            }
            $counter++;
        }  
        echo "</h1></br></br>";


 echo  "Task 5 c";  
        function finalPercentage($finalMark){
            $rCode = 0;
            if ($finalMark < 0 || $finalMark > 100){
             return -1;   
            }else{
              if ($finalMark >= 80 && $finalMark <= 100) { 
               $rCode = 7;
              }else if($finalMark >= 70 && $finalMark <= 79){ 
                $rCode = 6; 
              }else if($finalMark >= 60 && $finalMark <= 69){ 
                $rCode = 5;  
              }else if($finalMark >= 50 && $finalMark <= 59){ 
                $rCode = 4;  
              }else if($finalMark >= 40 && $finalMark <= 49){ 
                $rCode = 3;  
              }else if($finalMark >= 30 && $finalMark <= 39){ 
                $rCode = 2;  
              }else{
               $rCode = 1;   
              }
            }return $rCode;
        }
        echo "Rating Code: ".finalPercentage(5)."</br>";
        echo "Rating Code: ".finalPercentage(100)."</br>";
        echo "Rating Code: ".finalPercentage(101)."</br"; 
        echo "</br></br>";
          echo "</br></br>";
       function ratingCode($code){
        //$description = '';
        switch($code){
         case 7:
            $description ='outstanding';
            break; 
         case 6:
            $description ='Meritotious';
            break;
         case 5:
            $description ='Substantial';
            break;
         case 4:
            $description ='Adequate';
            break;
        case 3:
            $description ='Moderate';
            break;
        case 2:
            $description ='Elementary';
            break;
        case 1:
            $description ='Not achieved';
            break;
         Default: $description ='Invalid code';    
        }
       return $description;
       } 
         echo "Description: ".ratingCode(1)."</br>";
         echo "Description: ".ratingCode(7)."</br>";
         echo "Description: ".ratingCode(-1)."</br>";




                ?>
                
            </div>
           
            <!-- iframe containg PHP source code -->
            <iframe src="task7.txt" height="400" width="1200"> 
                Your browser does not support iframes. 
            </iframe>
        </main>
    </body>
</html>