<?php
    $student_name = 'Vusi Bhopape';
    $module_count = 4;
    define('MODULE_COST', 1825);
    $bursary_amt = 5000;
    
    // calculate total fee & outstanding fee
    $total_fee = $module_count * MODULE_COST;
    $outstanding_fee = abs($bursary_amt - $total_fee);
    
    //format output
    $module_cost_f = MODULE_COST;
    $total_fee_f = $total_fee;
    $bursary_amt_f = $bursary_amt;
    $outstanding_fee_f = $outstanding_fee;
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="main.css">
        <title>Task 1</title>
    </head>
    <body>
        <header>
            <?php include 'menu.inc'; ?>
        </header>
        
        <main>
            <!-- output -->
            <h2>Task 1</h2>
            <div class="output">
                <p>Student Name: <span><?php echo '<b>'.$student_name.'</b>' ?></span></p>
                <p>Number of modules registered: <span><?php echo '<b>'. $module_count.'</b>' ?></span></p>
                <p>Cost per module: <span><?php echo'R'.'<b>'. $module_cost_f.'</b>' ?></span></p>
                <p>Total fee: <span><?php echo'R'.'<b>'. $total_fee_f.'</b>' ?></span></p>
                <p>Outstanding amount: <span><?php echo'R'. '<b>'.$outstanding_fee_f.'</b>' ?></span></p>
            </div>
        
            <!-- iframe containg PHP source code -->
            <iframe src="task1.txt"> 
                Your browser does not support iframes. 
            </iframe>
        </main>
    </body>
</html>