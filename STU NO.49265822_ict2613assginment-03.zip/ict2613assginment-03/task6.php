<?php
    //task 6(a) using terneray operator
    function checkPay($day) {
        $payPerHour = ($day == 1) ? 19.20 : (($day == 7) ? 14.75 : 10.00);
        return $payPerHour;
    } 
    
    //task 6(b) using logical opertors
    function checkPromo($age, $income) {
        if ($age < 46) {
            if ($income >= 1000) {
                $qualify = TRUE;
            }
        } elseif ($income > 20000) {
            $qualify = TRUE;
        } else {
            $qualify = FALSE;
        }
        return $qualify;
    }
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="main.css">
        <title>Task 6</title>
    </head>
    <body>
        <header>
            <?php include 'menu.inc'; ?>
        </header>
        
        <main>
            <!-- output -->
            <h2>Output</h2>
            <div class="output">
                
                <!-- display output for task 6(a) -->
                <table>
                    <thead>
                        <tr>
                            <td>Days</td>
                            <td>Pay per hour</td>
                        </tr>                    
                    </thead>
                    <tr>
                        <td>-1</td>
                        <td>
                            <?php echo checkPay(-1); ?>
                        </td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>
                            <?php echo checkPay(1); ?>
                        </td>
                    </tr>
                    <tr>
                        <td>7</td>
                        <td>
                            <?php echo checkPay(7); ?>
                        </td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td><?php echo checkPay(5); ?></td>
                    </tr>
                </table>
                
                <!-- display output for task 6(b) -->
            </div>
          
             <!-- iframe containing PHP source code -->
            <iframe src="task6.txt">
                Your browser does not support iframes.
            </iframe>
        
        </main>
    </body>
</html>