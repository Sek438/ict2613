<?php
    
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="main.css">
        <title>Task 10</title>
    </head>
    <body>
        <header>
            <?php include 'menu.inc'; ?>
        </header>
        
        <main>
            <!-- output -->
            <h2>Output</h2>
            <div class="output">
<?php  

echo "Task 10a";

$count = 1;
$numbers = array();
while($count <= 15) {
    $numbers[] = rand(1,5);
    $count++;
}

foreach($numbers as $key=>$num) {
    echo $key. " - ".$num."<br>";
}

echo "<br><br>";

echo "Key: ".implode('Key: ', array_keys($numbers));

echo "<br><br>";
echo"ArrayCountValues: ";
print_r(array_count_values($numbers));

echo "<br><br>";
echo "ArraySum: ".array_sum($numbers);




echo "Task 10b";

$airLines = array(
    'SA' => 'SouthAfrican Airlines',
    'BA' => 'British Airlines',
    'EAL' => 'Etiopia Airlines',
    'KA' => 'Kenya Airlines',
    'CA' => 'China Airlines',
    'GB' => 'Gabon Airlines',
    'RA' => 'Russian Airlines',
);

foreach($airLines as $k=>$value) {
    echo $k." = ".$value."<br>";
}
echo "<br><br>";
rsort($airLines);
foreach($airLines as $k=>$value) {
    echo $k." = ".$value."<br>";
}
echo "<br><br>";
asort($airLines);
foreach($airLines as $k=>$value) {
    echo $k." = ".$value."<br>";
}













?>




                
            </div>
        
            <!-- iframe containg PHP source code -->
            <iframe src="task10.txt" height="400" width="1200"> 
                Your browser does not support iframes. 
            </iframe>
        </main>
    </body>
</html>