<?php
    // get values from form
    $student_name = filter_input(INPUT_GET, 'student_name');
    $module_count = filter_input(INPUT_GET, 'module_count', FILTER_VALIDATE_INT);
    $bursary_amt = filter_input(INPUT_GET, 'bursary_amt', FILTER_VALIDATE_FLOAT);

    // define constant
    define('MODULE_COST', 1825);

    // calculate total fee & outstanding fee
    $total_fee = $module_count * MODULE_COST;
    $outstanding_fee = abs($bursary_amt - $total_fee);
    
    //format output
    $module_cost_f = 'R'.MODULE_COST;
    $total_fee_f = 'R'.$total_fee;
    $bursary_amt_f = 'R'.$bursary_amt;
    $outstanding_fee_f = 'R'.$outstanding_fee;
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="main.css">
        <title>Task 2</title>
    </head>
    <body>
        <header>
            <?php include 'menu.inc'; ?>
        </header>
        
        <main>
            <!-- output -->
            <h2>Task 2</h2>
            <div class="output">
                <form action="task2.php" method="get">
                    <label for="student_name">Student Name: </label>
                    <input type="text" id="student_name" name="student_name"><br>
                    <label for="module_count">Number of modules: </label>
                    <input type="text" id="module_count" name="module_count"><br>
                    <label for="bursary_amt">Bursary amount: </label>
                    <input type="text" id="bursary_amt" name="bursary_amt"><br>
                    <label>&nbsp;</label>
                    <input type="submit" value="Sumbit"> 
                </form>
                <div>
                    <p>Student Name: <span><?php echo htmlspecialchars($student_name); ?></span></p>
                    <p>Number of modules registered: <span><?php echo htmlspecialchars($module_count); ?></span></p>
                    <p>Cost per module: <span><?php echo $module_cost_f; ?></span></p>
                    <p>Total fee: <span><?php echo $total_fee_f; ?></span></p>
                    <p>Bursary amount: <span><?php echo htmlspecialchars($bursary_amt_f); ?></span></p>
                    <p>Outstanding amount: <span><?php echo $outstanding_fee_f; ?></span></p>
                </div>
            </div>
            
            <!-- iframe containg PHP source code -->
            <iframe src="task2.txt"> 
                Your browser does not support iframes. 
            </iframe>
        </main>
    </body>
</html>