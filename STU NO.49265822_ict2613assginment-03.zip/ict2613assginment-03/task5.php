<?php 

include 'db_config.php';

/* ----- connect to the database -----*/
try {
    $db = new PDO(DATA_SOURCE_NAME, DATABASE_USERNAME, DATABASE_PASSWORD);
    $message = "Database connection successfull";
} catch (PDOException $e) {
    $message = "Error: " . $e->getMessage();
    exit();
}


/* ----- functions ----- */

//get all data from table
function query_all() {
    global $db;
    $query = "SELECT * FROM doctors "
            . "ORDER BY practicenumber";
    $statement = $db->prepare($query);
    $statement->execute();
    $results = $statement->fetchAll();
    $statement->closeCursor();
    return $results;
}

function practicenumber($practicenumber) {
    global $db;
    $query = "SELECT * FROM doctors "
            . "WHERE practicenumber = :practicenumber";
    $statement = $db->prepare($query);
    $statement->bindValue(':practicenumber', $practicenumber);
    $statement->execute();
    $result = $statement->fetch();
    return $result;
}

//update table with form data
function update($practicenumber, $name, $speciality, $fee) {
    global $db;
    $query = "UPDATE doctors "
            . "SET name = :name,  specialty = :specialty, fee = :fee "
            . "WHERE practicenumber = :practicenumber";
    $statement = $db->prepare($query);
    $statement->bindValue(':practicenumber', $practicenumber);
    $statement->bindValue(':name', $name);
    $statement->bindValue(':specialty', $speciality);
    $statement->bindValue(':fee', $fee);
    $statement->execute();
    $statement->closeCursor();
}

//delete data from table
function delete($practicenumber) {
    global $db;
    $query = "DELETE FROM doctors "
            . "WHERE practicenumber = :practicenumber";
    $statement = $db->prepare($query);
    $statement->bindValue(':practicenumber', $practicenumber);
    $statement->execute();
    $statement->closeCursor();
}

//insert data from form into table
function insert($practicenumber, $name, $speciality, $fee) {
    global $db;
    /* TODO add code to test if practicenumber already exists.
     * only a request to add a row with an existing 
     * practicenumber should be allowed.*/
    $query = "INSERT IGNORE INTO doctors "
            . "(practicenumber, name, specialty, fee) "
            . "VALUES "
            . "(:practicenumber, :name, :specialty, :fee)";
    $statement = $db->prepare($query);
    $statement->bindValue(':practicenumber', $practicenumber);
    $statement->bindValue(':name', $name);
    $statement->bindValue(':specialty', $speciality);
    $statement->bindValue(':fee', $fee);
    $statement->execute();
    $statement->closeCursor();
}

/* ----- instructions ----- */

/* call function to get full result set to
 * populate the table with all the data */
$query_results = query_all();

//declare variables
$option = filter_input(INPUT_POST, 'option');
$practicenumber = filter_input(INPUT_POST, 'practicenumber', FILTER_VALIDATE_INT);
$name = filter_input(INPUT_POST, 'name');
$speciality = filter_input(INPUT_POST, 'specialty');
$fee = filter_input(INPUT_POST, 'fee', FILTER_VALIDATE_FLOAT);
$error_message = "";
if (isset($_POST)) {
    if($option == 'add') {
        // test if practicenumber field contains a value
        if ($practicenumber != "" || $practicenumber != NULL) {
            // test if practice number exists
            $result = practicenumber($practicenumber);
            if ($result['practicenumber'] == $practicenumber) {
                $error_message = "That practice number already exists";
            } else {            
                 //insert new user data into table
                insert($practicenumber, $name, $speciality, $fee);
                // update table data
                $query_results = query_all();
            } //endif
        } else {
            $error_message = "Please enter a practice number";
        } //endif
        
                      
    } elseif ($option == 'update') {
        //get row with specified practice number
        $result = practicenumber($practicenumber);
        // test if practice number exists
        if ($practicenumber == $result['practicenumber']) {
            if ($name == "") {
                $name = $result['name'];
            } //endif
            if ($speciality == "") {
                $speciality = $result['specialty'];
            } //endif
            if ($fee == "") {
                $fee = $result['fee'];
            } //endif
            // update table with data from form
            update($practicenumber, $name, $speciality, $fee);
            // update table data
            $query_results = query_all();
        } else {
            $error_message = "That practice number does not exist";
        } // endif
        
    } elseif ($option == 'delete') {
        // delete data from table
        delete($practicenumber);
        // update table data
        $query_results = query_all();
    } //endif    
} //endif

?>

  <!DOCTYPE html>
  <html lang="en-GB">

  <head>
    <title>Task 5</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="main.css">

  </head>

  <body>
        <header>
            <?php include'menu.inc' ?>
        </header>
    
        <main>
            <!-- output -->
            <h2>Output</h2>
            <div class="output">
                <div class="info_message"><?php echo $message; ?></div><br>
                <div>
                    <!-- table display's db query results -->
                    <table>
                        <tr>
                            <th>Practice Number</th>
                            <th>Name</th>
                            <th>Speciality</th>
                            <th>Fee</th>
                        </tr>
                        <!-- populate table with the query results with a foreach loop -->
                        <?php foreach ($query_results as $result) : ?>
                        <tr>
                            <td>
                                <?php echo $result['practicenumber']; ?>
                            </td>
                            <td>
                                <?php echo $result['name']; ?>
                            </td>
                            <td>
                                <?php echo $result['specialty']; ?>
                            </td>
                            <td class="numbers_col">
                                <?php echo $result['fee']; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <br>
                
                <?php if ($error_message != NULL || $error_message != "") : ?>
                <div class="error_message"><?php echo $error_message; ?></div><br>
                <?php endif; ?>
                
                <div>
                    <form action="task5.php" method="post">
                        <label for="option">Select an option: </label>
                        <select name="option">
                            <option value="add">Add</option>
                            <option value="update">Update</option>
                            <option value="delete">Delete</option>
                        </select>
                        <br>
                        <label for="practicenumber">Practice Number: </label>
                        <input type="text" name="practicenumber"><br>
                        <label for="name">Name: </label>
                        <input type="text" name="name"><br>
                        <label for="speciality">Speciality: </label>
                        <input type="text" name="specialty"><br>
                        <label for="fee">Fee: </label>
                        <input type="text" name="fee"><br>
                        <label>&nbsp;</label>
                        <input type="submit" value="Submit"/>
                    </form>
                </div>
            </div>
            
         
            <!-- iframe containing PHP source code -->
            <iframe src="task5.txt">
                Your browser does not support iframes.
            </iframe>
        
      </main>
  </body>

  </html>