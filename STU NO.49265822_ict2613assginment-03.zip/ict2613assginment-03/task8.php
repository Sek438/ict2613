<?php
    
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="main.css">
        <title>Task 7</title>
    </head>
    <body>
        <header>
            <?php include 'menu.inc'; ?>
        </header>
        
        <main>
            <!-- output -->
            <h2>Output</h2>
            <div class="output">

<?php
$sentence = "All for one and one for all";

echo "Input sentence: ".$sentence."<br>";

echo "Length: ".strlen($sentence)."<br>";

echo "Reverse: ".strrev($sentence)."<br>";

echo "Colon separated format: ".str_replace(' ', ':', $sentence)."<br>";

echo "A and a replaced by * : ".preg_replace('/(a|A)/', '*', $sentence)."<br>";

$str = (explode(' ', $sentence));

$string = "";
foreach($str as $lchar) {
    $string .= substr($lchar, -1);
}

echo "Last letters in lowercase: ".strtolower($string)."<br>";

echo "Uppercase words: ".ucwords($sentence)."<br>";

$string = "";
foreach($str as $fchar) {
    $string .= substr($fchar, 0,1);
}

echo "Uppercase words without spaces: ".strtoupper($string)."<br>";
?>

                
            </div>
           
            <!-- iframe containg PHP source code -->
            <iframe src="task8.txt" height="400" width="1200"> 
                Your browser does not support iframes. 
            </iframe>
        </main>
    </body>
</html>